﻿# 轮播图

轮播图视频推荐5，默认8个，需要更改数量，打开index/slide.html，看到num="8"，把数字改成你想要显示轮播数字即可。

# 首页热播

热播视频推荐1，数量16个。

# 弹窗公告和网址

弹窗公告内容修改-------public/tcnotice

网址内容修改----------public/website.html

# 其他页面

label/app==app下载页  label/about==关于  label/help==投屏  label/web==网址

# 搜索筛选验证码模板

/html/public/verify.html
